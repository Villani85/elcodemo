# Account Fields Generation Report

**VAT Field**: Partita_IVA__c

## Created Fields (29)

- Partita_IVA__c
- CRIF_Stato_Attivita__c
- CRIF_Fatturato__c
- CRIF_Fatturato_Anno__c
- CRIF_Numero_Dipendenti__c
- CRIF_EBITDA__c
- CRIF_Valore_Credito__c
- CRIF_Last_Status__c
- CRIF_Last_Refresh__c
- CRIF_VAT_Normalized__c
- CRIF_Company_Id__c
- CRIF_Real_Estate_Lease_Score__c
- CRIF_Factoring_Score__c
- CRIF_DnB_Rating__c
- CRIF_Has_Delinquency_Notices__c
- CRIF_Has_Negative_Notices__c
- CRIF_Has_Bankruptcy_Notices__c
- CRIF_Last_Http_Status__c
- CRIF_Correlation_Id__c
- CRIF_Last_Error__c
- CRIF_Last_Request_Timestamp__c
- CRIF_Last_Response_Timestamp__c
- CRIF_Last_Duration_ms__c
- CRIF_Last_Raw_JSON__c
- Admin_Fatturato_Effettivo__c
- Admin_Last_Status__c
- Admin_Last_Refresh__c
- Tableau_Customer_Key__c
- Tableau_Last_Data_Refresh__c

## Updated Fields (0)


## Skipped Fields (0)


## Type Mismatches (0)

