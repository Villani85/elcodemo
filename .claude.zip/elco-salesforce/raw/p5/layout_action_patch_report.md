# Layout Action Patch Report
## Account
- File: force-app/main/default/layouts/Account-Account Layout.layout-meta.xml
- Actions added: 5
- Actions skipped (already present): 0
- Target actions: Account.CRIF_Aggiorna_Dati, Account.CRIF_Storico, Account.Storico_Offerte, Account.Gestisci_Specifiche_Tecniche, Account.Crea_Report_Visita

## Opportunity
- File: force-app/main/default/layouts/Opportunity-Opportunity Layout.layout-meta.xml
- Actions added: 1
- Actions skipped (already present): 0
- Target actions: Opportunity.Crea_Offerta

## Quote
- File: force-app/main/default/layouts/Quote-Quote Layout.layout-meta.xml
- Actions added: 1
- Actions skipped (already present): 0
- Target actions: Quote.Aggiungi_Riga_Offerta

## QuoteLineItem
- File: force-app/main/default/layouts/QuoteLineItem-Quote Line Item Layout.layout-meta.xml
- Actions added: 0
- Actions skipped (already present): 0
- Target actions: 

## Visit_Report__c
- File: force-app/main/default/layouts/Visit_Report__c-Report Visita Layout.layout-meta.xml
- Actions added: 1
- Actions skipped (already present): 0
- Target actions: Visit_Report__c.Invia_Followup

## Summary
- Total actions added: 8
- Total actions skipped: 0
