# Layout Field Patch Report

## Account
- File: force-app/main/default/layouts/Account-Account Layout.layout-meta.xml
- Sections created: 0
- Fields added: 0
- Fields skipped (already present): 36

## Opportunity
- File: force-app/main/default/layouts/Opportunity-Opportunity Layout.layout-meta.xml
- Sections created: 0
- Fields added: 0
- Fields skipped (already present): 0

## Quote
- File: force-app/main/default/layouts/Quote-Quote Layout.layout-meta.xml
- Sections created: 0
- Fields added: 0
- Fields skipped (already present): 10

## QuoteLineItem
- File: force-app/main/default/layouts/QuoteLineItem-Quote Line Item Layout.layout-meta.xml
- Sections created: 0
- Fields added: 0
- Fields skipped (already present): 13

## Visit_Report__c
- File: force-app/main/default/layouts/Visit_Report__c-Report Visita Layout.layout-meta.xml
- Sections created: 0
- Fields added: 0
- Fields skipped (already present): 2

## Summary
- Total sections created: 0
- Total fields added: 0
- Total fields skipped: 61
