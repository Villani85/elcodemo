# Quick Actions Normalize & Patch Report

## Quote-Quote Layout
- platformActionListId removed: 0
- recordActionLists: 0 -> 1
- Items: 0 -> 1
- Actions added: 1
- Actions skipped: 0

## Visit_Report__c-Report Visita Layout
- platformActionListId removed: 0
- recordActionLists: 0 -> 1
- Items: 0 -> 1
- Actions added: 1
- Actions skipped: 0

## Summary
- Total actions added: 2
- Total actions skipped: 0
