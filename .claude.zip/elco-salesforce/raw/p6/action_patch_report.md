# Quick Actions Patch Report

## Account-Account Layout.layout-meta.xml
- File: `force-app/main/default/layouts/Account-Account Layout.layout-meta.xml`
- Actions added: 5
- Actions skipped (already present): 0
- Target actions:
  - Account.CRIF_Aggiorna_Dati
  - Account.CRIF_Storico
  - Account.Storico_Offerte
  - Account.Gestisci_Specifiche_Tecniche
  - Account.Crea_Report_Visita

## Opportunity-Opportunity Layout.layout-meta.xml
- File: `force-app/main/default/layouts/Opportunity-Opportunity Layout.layout-meta.xml`
- Actions added: 1
- Actions skipped (already present): 0
- Target actions:
  - Opportunity.Crea_Offerta

## Summary
- Total actions added: 6
- Total actions skipped: 0

**Result**: Layouts patched and ready for deployment.
