# FLS Diff Report - Expected vs Current

**Generated**: 2026-02-20 17:10

---

## Quote_Operator

- **Expected**: 30 fields
- **Current**: 30 fields
- **Missing**: 0 fields
- **Extra**: 0 fields

[OK] **Perfect match!**

---

## Visit_Operator

- **Expected**: 5 fields
- **Current**: 5 fields
- **Missing**: 0 fields
- **Extra**: 0 fields

[OK] **Perfect match!**

---

## TechSpec_Operator

- **Expected**: 4 fields
- **Current**: 4 fields
- **Missing**: 0 fields
- **Extra**: 0 fields

[OK] **Perfect match!**

---

